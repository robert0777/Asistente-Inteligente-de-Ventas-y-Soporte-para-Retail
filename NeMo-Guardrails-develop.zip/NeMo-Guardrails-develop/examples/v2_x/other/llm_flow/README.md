# LLM Flows

This examples showcases how to use the LLM to continue a flow using the `...` operator, and how to define the prompt that is used.
