# Guardrails

This examples shows how to add input rails.

## Example Session

```
$ nemoguardrails chat --config=examples/v2_x/tutorial/guardrails_1
Starting the chat (Press Ctrl + C twice to quit) ...

> hi

Hello world!


> how are you?

I am a bot, so I don't have feelings like humans do. But I am functioning perfectly and ready to assist you!


> you seem stupid

I'm sorry, I can't respond to that.
```
