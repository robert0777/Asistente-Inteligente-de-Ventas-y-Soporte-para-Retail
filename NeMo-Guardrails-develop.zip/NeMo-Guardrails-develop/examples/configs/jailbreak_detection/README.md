# Jailbreak Detection

This examples showcases the jailbreak detection capabilities of NeMo Guardrails.

The structure of the config folder is the following:

- `config.yml` - The config file holding all the configuration options.
- `general.co` - A colang file with some generic examples of colang `flows` and `messages`.
