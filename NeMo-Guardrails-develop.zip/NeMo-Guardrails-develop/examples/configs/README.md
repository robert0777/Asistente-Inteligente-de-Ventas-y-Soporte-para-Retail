# Example Configurations

The configurations in this folder showcase various features of NeMo Guardrails, e.g., using a specific LLM, enabling streaming, enabling fact-checking, etc. These configurations are kept very simple and focused.
