# RAG Examples

The examples in this folder showcase various features of NeMo Guardrails related to RAG (Retrieval Augmented Generation).
