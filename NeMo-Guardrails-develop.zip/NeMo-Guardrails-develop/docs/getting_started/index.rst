:orphan:

Getting Started
===============

.. toctree::
   :maxdepth: 2

   installation-guide
   README

.. toctree::
   :maxdepth: 2
   :hidden:

   1_hello_world/index
   2_core_colang_concepts/index
   3_demo_use_case/index
   4_input_rails/index
   5_output_rails/index
   6_topical_rails/index
   7_rag/index
