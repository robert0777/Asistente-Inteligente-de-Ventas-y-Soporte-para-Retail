Jailbreak Detection Heuristics
==============================

.. toctree::
   :maxdepth: 2

   README
