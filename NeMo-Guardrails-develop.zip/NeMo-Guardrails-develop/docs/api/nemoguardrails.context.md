<!-- markdownlint-disable -->

<a href="../../nemoguardrails/context.py#L0"><img align="right" style="float:right;" src="https://img.shields.io/badge/-source-cccccc?style=flat-square" /></a>

# <kbd>module</kbd> `nemoguardrails.context`




**Global Variables**
---------------
- **streaming_handler_var**
- **explain_info_var**
- **llm_call_info_var**
