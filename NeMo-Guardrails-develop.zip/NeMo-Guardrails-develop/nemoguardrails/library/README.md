# NeMo Guardrails Library

The library contains a set of pre-built rails that can be activated in any config.
