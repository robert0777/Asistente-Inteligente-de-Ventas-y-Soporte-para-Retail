# Colang

This package implements the Colang parser.

** NOTE: the parser supports parsing the full Colang language, but the runtime currently supports a stripped down version of the language. **

** NOTE: for some parts of the colang code, the parser implementation creates an intermediate Markdown format, which then gets parsed again. This is for historical reasons. Will be removed in the future. **

TODO: document the relevant syntax.
